﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ĐOAN_QLBD
{
    public static class Global
    {
        public static string TenDangNhap { get; set; }
        public static string MatKhau { get; set; }

        public static string Quyen { get; set; }
    }
}
